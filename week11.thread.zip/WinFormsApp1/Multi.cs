using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Multi : Form
    {
        public Multi()
        {
            InitializeComponent();
        }

        private async Task GenerateFibonacciNumbersAsync(int number)
        {
            await Task.Run(() =>
            {
                for (int i = 0; i <= number; i++)
                {
                    long result = CalculateFibonacci(i);

                    this.Invoke((MethodInvoker)delegate
                    {
                        lbxGenerate.Items.Add($"Fib({i}) = {result}");
                    });
                    Thread.Sleep(50);
                }
            });
        }

        private long CalculateFibonacci(int n)
        {
            if (n <= 0) return 0;
            if (n == 1) return 1;

            long previous = 0;
            long current = 1;
            for (int i = 2; i <= n; i++)
            {
                long temp = current;
                current += previous;
                previous = temp;
            }
            return current;
        }
    }
}
