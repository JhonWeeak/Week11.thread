﻿
namespace WinFormsApp1
{
    partial class Multi
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tbxGenerate = new TextBox();
            btnGenerate = new Button();
            lbxGenerate = new ListBox();
            SuspendLayout();
            // 
            // tbxGenerate
            // 
            tbxGenerate.Location = new Point(41, 40);
            tbxGenerate.Name = "tbxGenerate";
            tbxGenerate.Size = new Size(164, 30);
            tbxGenerate.TabIndex = 0;
            tbxGenerate.TextChanged += this.tbxGenerate_TextChanged;
            // 
            // btnGenerate
            // 
            btnGenerate.Location = new Point(242, 40);
            btnGenerate.Name = "btnGenerate";
            btnGenerate.Size = new Size(164, 30);
            btnGenerate.TabIndex = 1;
            btnGenerate.Text = "Generate";
            btnGenerate.UseVisualStyleBackColor = true;
            btnGenerate.Click += btnGenerate_Click;
            // 
            // lbxGenerate
            // 
            lbxGenerate.FormattingEnabled = true;
            lbxGenerate.ItemHeight = 24;
            lbxGenerate.Location = new Point(41, 113);
            lbxGenerate.Name = "lbxGenerate";
            lbxGenerate.Size = new Size(365, 292);
            lbxGenerate.TabIndex = 2;
            lbxGenerate.SelectedIndexChanged += lbxGenerate_SelectedIndexChanged;
            // 
            // Multi
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lbxGenerate);
            Controls.Add(btnGenerate);
            Controls.Add(tbxGenerate);
            Name = "Multi";
            Text = "multi";
            Load += Multi_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        private void tbxGenerate_TextChanged(object sender, EventArgs e)
        {
        }

        private void Multi_Load_1(object sender, EventArgs e)
        {
        }

        private void lbxGenerate_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {

            lbxGenerate.Items.Clear();


            if (!int.TryParse(tbxGenerate.Text, out int number) || number < 0)
            {
                MessageBox.Show("Please enter a valid non-negative integer.");
                return;
            }

            GenerateFibonacciNumbersAsync(number);
        }

        #endregion

        private TextBox tbxGenerate;
        private Button btnGenerate;
        private ListBox lbxGenerate;
    }
}
